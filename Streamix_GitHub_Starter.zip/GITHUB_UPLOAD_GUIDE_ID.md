# Panduan upload Streamix ke GitHub lewat HP

1. Buat repository baru di GitHub bernama `Streamix-Android`.
2. Pilih **Public** atau **Private** sesuai keinginan. Jangan centang Add README, .gitignore, atau license karena file sudah ada di paket ini.
3. Unduh dan ekstrak `Streamix_GitHub_Starter.zip` di HP.
4. Buka repository GitHub di Chrome, aktifkan **Situs desktop** bila perlu.
5. Pilih **Add file → Upload files**.
6. Unggah seluruh ISI folder `Streamix_GitHub` (termasuk folder `.github`).
7. Pastikan `settings.gradle.kts`, `build.gradle.kts`, folder `app`, dan `.github/workflows/android-build.yml` berada di root repository.
8. Tekan **Commit changes**.

## Build APK
- Buka tab **Actions** pada repository.
- Pilih workflow **Build Streamix APK**.
- Tekan **Run workflow** bila belum berjalan otomatis.
- Buka hasil run yang selesai, lalu unduh artifact `streamix-debug-apk`.
- Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.

Catatan:
- Ini starter project, bukan aplikasi final.
- Widget Media, PNGTuber, dan Web masih placeholder.
- APK debug untuk pengujian; belum ditandatangani untuk rilis Play Store.
