package com.streamix.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Navy = Color(0xFF0B1020)
private val Panel = Color(0xFF151D35)
private val Cyan = Color(0xFF42D9F5)
private val Violet = Color(0xFF8665FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan,
                    secondary = Violet,
                    background = Navy,
                    surface = Panel
                )
            ) {
                Dashboard(
                    onStartOverlay = {
                        if (Settings.canDrawOverlays(this)) {
                            ContextCompat.startForegroundService(
                                this, Intent(this, OverlayService::class.java)
                            )
                        } else {
                            startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")
                                )
                            )
                        }
                    },
                    overlayAllowed = Settings.canDrawOverlays(this)
                )
            }
        }
    }
}

@Composable
private fun Dashboard(onStartOverlay: () -> Unit, overlayAllowed: Boolean) {
    var showInfo by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Navy, Color(0xFF17264A), Color(0xFF24194B)))
        ).padding(22.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text("STREAMIX", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
            Text("Your stream. Your layout.", color = Color(0xFF9FB2D7), fontSize = 14.sp)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xCC17233F)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Layers, null, tint = Cyan)
                        Spacer(Modifier.width(10.dp))
                        Text("Overlay workspace", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "Atur widget Media, PNGTuber, Web, dan Text di atas game.",
                        color = Color(0xFFB8C5DF)
                    )
                    Button(
                        onClick = onStartOverlay,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Violet),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (overlayAllowed) "Aktifkan Floating Overlay" else "Izinkan Overlay")
                    }
                    Text(
                        if (overlayAllowed) "Izin overlay sudah aktif." else "Streamix membutuhkan izin tampil di atas aplikasi lain.",
                        color = if (overlayAllowed) Cyan else Color(0xFFFFC66D),
                        fontSize = 12.sp
                    )
                }
            }
            OutlinedButton(
                onClick = { showInfo = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Tune, null)
                Spacer(Modifier.width(8.dp))
                Text("Tentang versi awal")
            }
        }
        Text(
            "BETA 0.1.0",
            color = Color(0xFF8292B5),
            modifier = Modifier.align(Alignment.BottomCenter),
            fontSize = 11.sp
        )
    }
    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Streamix — MVP") },
            text = { Text("Versi awal ini menyiapkan dashboard, floating bubble, panel kontrol, dan kerangka widget. Fitur editor dan penyimpanan layout akan dikembangkan bertahap.") },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Mengerti") } }
        )
    }
}
