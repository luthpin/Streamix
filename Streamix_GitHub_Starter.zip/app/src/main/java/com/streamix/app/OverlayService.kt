package com.streamix.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import kotlin.math.max

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var isPanelOpen = false
    private val widgets = mutableListOf<View>()
    private var globalOpacity = 1f

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        showBubble()
    }

    private fun createNotification() {
        val channelId = "streamix_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Streamix Overlay", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("Streamix aktif")
                .setContentText("Floating overlay sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Streamix aktif")
                .setContentText("Floating overlay sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
        startForeground(41, notification)
    }

    private fun lp(width: Int, height: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            setStroke(dp(1), Color.argb(45, 120, 190, 255))
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "S"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(44, 190, 245), Color.rgb(113, 76, 255))
            ).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            elevation = dp(8).toFloat()
        }
        val p = lp(dp(54), dp(54)).apply {
            x = 0; y = resources.displayMetrics.heightPixels / 2
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f
            var startX = 0; var startY = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = p.x; startY = p.y; moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt()
                        val dy = (e.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                        p.x = max(0, startX + dx)
                        p.y = max(0, startY + dy)
                        wm.updateViewLayout(b, p)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        else {
                            val screenW = resources.displayMetrics.widthPixels
                            p.x = if (p.x + dp(54) / 2 < screenW / 2) 0 else screenW - dp(54)
                            wm.updateViewLayout(b, p)
                        }
                        return true
                    }
                }
                return true
            }
        })
        bubble = b
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (isPanelOpen) closePanel() else openPanel()
    }

    private fun openPanel() {
        if (isPanelOpen) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(Color.argb(245, 14, 20, 38), dp(24).toFloat())
            elevation = dp(16).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "STREAMIX  •  CONTROL"
            textSize = 14f; setTextColor(Color.WHITE); setTypeface(null, 1)
        }
        val close = TextView(this).apply {
            text = "×"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = rounded(Color.rgb(43, 53, 78), dp(30).toFloat())
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(header)
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(12))
        }
        actions.addView(actionButton("＋\nAdd Widget") { showAddWidget() }, weighted())
        actions.addView(actionButton("▤\nLayers") { showLayers() }, weighted())
        actions.addView(actionButton("■\nHide") { hideWidgets() }, weighted())
        root.addView(actions)
        val opacityLabel = TextView(this).apply {
            text = "Transparansi overlay: 100%"
            textSize = 12f; setTextColor(Color.LTGRAY)
        }
        root.addView(opacityLabel)
        val seek = SeekBar(this).apply {
            max = 100; progress = 100
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(75, 145, 255))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(104, 113, 255))
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                globalOpacity = value / 100f
                opacityLabel.text = "Transparansi overlay: $value%"
                widgets.forEach { it.alpha = globalOpacity }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)
        val hint = TextView(this).apply {
            text = "Tekan bubble Streamix untuk menutup panel"
            textSize = 10f; setTextColor(Color.rgb(145, 163, 198))
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(hint)
        close.setOnClickListener { closePanel() }

        val params = lp(dp(330), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(88)
        }
        panel = root
        panelParams = params
        wm.addView(root, params)
        isPanelOpen = true
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(74), 1f).apply {
        marginStart = dp(4); marginEnd = dp(4)
    }

    private fun actionButton(label: String, click: () -> Unit): View =
        TextView(this).apply {
            text = label; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = rounded(Color.rgb(37, 53, 88), dp(16).toFloat())
            setOnClickListener { click() }
        }

    private fun showAddWidget() {
        val choices = arrayOf("Media", "PNGTuber", "Web", "Text")
        android.app.AlertDialog.Builder(this)
            .setTitle("Add Widget")
            .setItems(choices) { _, which ->
                val name = choices[which]
                addDemoWidget(name)
            }
            .setNegativeButton("Batal", null)
            .show()
            .window?.setType(overlayType())
    }

    private fun addDemoWidget(name: String) {
        val label = TextView(this).apply {
            text = when (name) {
                "Text" -> "Your text"
                "Web" -> "Web widget"
                "PNGTuber" -> "PNGTuber"
                else -> "Media"
            }
            textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(Color.argb(220, 28, 45, 78), dp(12).toFloat())
            alpha = globalOpacity
            setOnClickListener { editWidget(this) }
        }
        val params = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(130 + widgets.size * 64)
        }
        wm.addView(label, params)
        widgets.add(label)
        Toast.makeText(this, "$name ditambahkan — ketuk widget untuk mengedit", Toast.LENGTH_SHORT).show()
    }

    private fun editWidget(view: View) {
        val input = EditText(this).apply {
            setText((view as? TextView)?.text ?: "")
            setTextColor(Color.WHITE)
            hint = "Nama / teks widget"
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Widget Settings")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                (view as? TextView)?.text = input.text.toString()
            }
            .setNegativeButton("Hapus") { _, _ ->
                wm.removeView(view); widgets.remove(view)
            }
            .setNeutralButton("Batal", null)
            .show()
            .window?.setType(overlayType())
    }

    private fun showLayers() {
        val names = widgets.mapIndexed { i, v -> "${i + 1}. ${(v as? TextView)?.text ?: "Widget"}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("Layers (${widgets.size})")
            .setItems(names) { _, index -> editWidget(widgets[index]) }
            .setPositiveButton("Selesai", null)
            .show()
            .window?.setType(overlayType())
    }

    private fun hideWidgets() {
        widgets.forEach { it.visibility = View.GONE }
        Toast.makeText(this, "Widget disembunyikan sementara", Toast.LENGTH_SHORT).show()
    }

    private fun closePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        isPanelOpen = false
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY

    override fun onDestroy() {
        closePanel()
        bubble?.let { runCatching { wm.removeView(it) } }
        widgets.toList().forEach { runCatching { wm.removeView(it) } }
        widgets.clear()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
