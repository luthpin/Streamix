# Streamix Android — MVP 0.1.0

Starter project Android native menggunakan Kotlin, Jetpack Compose untuk dashboard, dan WindowManager untuk floating overlay.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `Streamix` melalui Android Studio.
3. Gunakan JDK 17.
4. Tunggu Gradle Sync selesai.
5. Jalankan pada perangkat Android 8.0+.

## Yang sudah disiapkan
- Dashboard Streamix.
- Permintaan izin tampil di atas aplikasi lain.
- Foreground service untuk menjaga overlay berjalan.
- Floating bubble yang bisa digeser dan snap ke sisi layar.
- Control panel dengan Add Widget, Layers, Hide, dan opacity global.
- Pilihan Media, PNGTuber, Web, Text.
- Widget demo yang bisa diganti teks dan dihapus.

## Batasan versi awal
Widget Media/PNGTuber/Web saat ini masih placeholder, belum memuat file gambar, avatar PNGTuber, atau halaman web sungguhan. Editor posisi/ukuran, tab Appearance/Animation/Advanced, penyimpanan layout, dan pengelolaan layer penuh adalah tahap berikutnya.

## Catatan Android
Izin overlay harus diberikan manual dari pengaturan Android. Android 13+ dapat meminta izin notifikasi. Kebijakan foreground service Android terbaru dapat berbeda menurut versi OS dan distribusi aplikasi; periksa persyaratan Google Play sebelum rilis publik.
